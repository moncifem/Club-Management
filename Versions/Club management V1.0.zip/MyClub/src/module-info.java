module Club {
	requires java.desktop;
	requires com.formdev.flatlaf;
}